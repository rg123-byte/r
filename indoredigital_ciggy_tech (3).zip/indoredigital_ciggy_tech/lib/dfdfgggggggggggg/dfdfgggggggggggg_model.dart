import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dfdfgggggggggggg_widget.dart' show DfdfggggggggggggWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DfdfggggggggggggModel extends FlutterFlowModel<DfdfggggggggggggWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
