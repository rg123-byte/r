import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBbP0_3xpkfJI_Y42kYMfOiM7MRrTcjZnM",
            authDomain: "indoredigital-ciggy-tec-3g3qll.firebaseapp.com",
            projectId: "indoredigital-ciggy-tec-3g3qll",
            storageBucket: "indoredigital-ciggy-tec-3g3qll.appspot.com",
            messagingSenderId: "542353293999",
            appId: "1:542353293999:web:0921498d7b392b57374a5a"));
  } else {
    await Firebase.initializeApp();
  }
}
