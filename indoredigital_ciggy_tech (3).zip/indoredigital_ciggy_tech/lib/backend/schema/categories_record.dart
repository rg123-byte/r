import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CategoriesRecord extends FirestoreRecord {
  CategoriesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "name1" field.
  String? _name1;
  String get name1 => _name1 ?? '';
  bool hasName1() => _name1 != null;

  // "imageUrl" field.
  String? _imageUrl;
  String get imageUrl => _imageUrl ?? '';
  bool hasImageUrl() => _imageUrl != null;

  // "rate" field.
  String? _rate;
  String get rate => _rate ?? '';
  bool hasRate() => _rate != null;

  // "review" field.
  String? _review;
  String get review => _review ?? '';
  bool hasReview() => _review != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _name1 = snapshotData['name1'] as String?;
    _imageUrl = snapshotData['imageUrl'] as String?;
    _rate = snapshotData['rate'] as String?;
    _review = snapshotData['review'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('categories');

  static Stream<CategoriesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CategoriesRecord.fromSnapshot(s));

  static Future<CategoriesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CategoriesRecord.fromSnapshot(s));

  static CategoriesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CategoriesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CategoriesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CategoriesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CategoriesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CategoriesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCategoriesRecordData({
  String? name,
  String? name1,
  String? imageUrl,
  String? rate,
  String? review,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'name1': name1,
      'imageUrl': imageUrl,
      'rate': rate,
      'review': review,
    }.withoutNulls,
  );

  return firestoreData;
}

class CategoriesRecordDocumentEquality implements Equality<CategoriesRecord> {
  const CategoriesRecordDocumentEquality();

  @override
  bool equals(CategoriesRecord? e1, CategoriesRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.name1 == e2?.name1 &&
        e1?.imageUrl == e2?.imageUrl &&
        e1?.rate == e2?.rate &&
        e1?.review == e2?.review;
  }

  @override
  int hash(CategoriesRecord? e) => const ListEquality()
      .hash([e?.name, e?.name1, e?.imageUrl, e?.rate, e?.review]);

  @override
  bool isValidKey(Object? o) => o is CategoriesRecord;
}
