import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SearchhistoryRecord extends FirestoreRecord {
  SearchhistoryRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "number" field.
  String? _number;
  String get number => _number ?? '';
  bool hasNumber() => _number != null;

  // "adress" field.
  String? _adress;
  String get adress => _adress ?? '';
  bool hasAdress() => _adress != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "Business" field.
  String? _business;
  String get business => _business ?? '';
  bool hasBusiness() => _business != null;

  // "name2" field.
  String? _name2;
  String get name2 => _name2 ?? '';
  bool hasName2() => _name2 != null;

  // "imageUrl" field.
  String? _imageUrl;
  String get imageUrl => _imageUrl ?? '';
  bool hasImageUrl() => _imageUrl != null;

  // "vendorId" field.
  String? _vendorId;
  String get vendorId => _vendorId ?? '';
  bool hasVendorId() => _vendorId != null;

  // "keyword" field.
  String? _keyword;
  String get keyword => _keyword ?? '';
  bool hasKeyword() => _keyword != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _number = snapshotData['number'] as String?;
    _adress = snapshotData['adress'] as String?;
    _email = snapshotData['email'] as String?;
    _business = snapshotData['Business'] as String?;
    _name2 = snapshotData['name2'] as String?;
    _imageUrl = snapshotData['imageUrl'] as String?;
    _vendorId = snapshotData['vendorId'] as String?;
    _keyword = snapshotData['keyword'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('searchhistory')
          : FirebaseFirestore.instance.collectionGroup('searchhistory');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('searchhistory').doc(id);

  static Stream<SearchhistoryRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SearchhistoryRecord.fromSnapshot(s));

  static Future<SearchhistoryRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SearchhistoryRecord.fromSnapshot(s));

  static SearchhistoryRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SearchhistoryRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SearchhistoryRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SearchhistoryRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SearchhistoryRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SearchhistoryRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSearchhistoryRecordData({
  String? name,
  String? number,
  String? adress,
  String? email,
  String? business,
  String? name2,
  String? imageUrl,
  String? vendorId,
  String? keyword,
  DateTime? timestamp,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'number': number,
      'adress': adress,
      'email': email,
      'Business': business,
      'name2': name2,
      'imageUrl': imageUrl,
      'vendorId': vendorId,
      'keyword': keyword,
      'timestamp': timestamp,
    }.withoutNulls,
  );

  return firestoreData;
}

class SearchhistoryRecordDocumentEquality
    implements Equality<SearchhistoryRecord> {
  const SearchhistoryRecordDocumentEquality();

  @override
  bool equals(SearchhistoryRecord? e1, SearchhistoryRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.number == e2?.number &&
        e1?.adress == e2?.adress &&
        e1?.email == e2?.email &&
        e1?.business == e2?.business &&
        e1?.name2 == e2?.name2 &&
        e1?.imageUrl == e2?.imageUrl &&
        e1?.vendorId == e2?.vendorId &&
        e1?.keyword == e2?.keyword &&
        e1?.timestamp == e2?.timestamp;
  }

  @override
  int hash(SearchhistoryRecord? e) => const ListEquality().hash([
        e?.name,
        e?.number,
        e?.adress,
        e?.email,
        e?.business,
        e?.name2,
        e?.imageUrl,
        e?.vendorId,
        e?.keyword,
        e?.timestamp
      ]);

  @override
  bool isValidKey(Object? o) => o is SearchhistoryRecord;
}
