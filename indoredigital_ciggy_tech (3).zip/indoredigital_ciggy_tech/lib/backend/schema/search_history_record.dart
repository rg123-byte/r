import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SearchHistoryRecord extends FirestoreRecord {
  SearchHistoryRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "phonenumber" field.
  String? _phonenumber;
  String get phonenumber => _phonenumber ?? '';
  bool hasPhonenumber() => _phonenumber != null;

  // "keyword" field.
  String? _keyword;
  String get keyword => _keyword ?? '';
  bool hasKeyword() => _keyword != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "assignedTo" field.
  String? _assignedTo;
  String get assignedTo => _assignedTo ?? '';
  bool hasAssignedTo() => _assignedTo != null;

  // "vendorId" field.
  String? _vendorId;
  String get vendorId => _vendorId ?? '';
  bool hasVendorId() => _vendorId != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  void _initializeFields() {
    _phonenumber = snapshotData['phonenumber'] as String?;
    _keyword = snapshotData['keyword'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _email = snapshotData['email'] as String?;
    _name = snapshotData['name'] as String?;
    _assignedTo = snapshotData['assignedTo'] as String?;
    _vendorId = snapshotData['vendorId'] as String?;
    _status = snapshotData['status'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('searchHistory');

  static Stream<SearchHistoryRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SearchHistoryRecord.fromSnapshot(s));

  static Future<SearchHistoryRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SearchHistoryRecord.fromSnapshot(s));

  static SearchHistoryRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SearchHistoryRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SearchHistoryRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SearchHistoryRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SearchHistoryRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SearchHistoryRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSearchHistoryRecordData({
  String? phonenumber,
  String? keyword,
  DateTime? timestamp,
  String? email,
  String? name,
  String? assignedTo,
  String? vendorId,
  String? status,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'phonenumber': phonenumber,
      'keyword': keyword,
      'timestamp': timestamp,
      'email': email,
      'name': name,
      'assignedTo': assignedTo,
      'vendorId': vendorId,
      'status': status,
    }.withoutNulls,
  );

  return firestoreData;
}

class SearchHistoryRecordDocumentEquality
    implements Equality<SearchHistoryRecord> {
  const SearchHistoryRecordDocumentEquality();

  @override
  bool equals(SearchHistoryRecord? e1, SearchHistoryRecord? e2) {
    return e1?.phonenumber == e2?.phonenumber &&
        e1?.keyword == e2?.keyword &&
        e1?.timestamp == e2?.timestamp &&
        e1?.email == e2?.email &&
        e1?.name == e2?.name &&
        e1?.assignedTo == e2?.assignedTo &&
        e1?.vendorId == e2?.vendorId &&
        e1?.status == e2?.status;
  }

  @override
  int hash(SearchHistoryRecord? e) => const ListEquality().hash([
        e?.phonenumber,
        e?.keyword,
        e?.timestamp,
        e?.email,
        e?.name,
        e?.assignedTo,
        e?.vendorId,
        e?.status
      ]);

  @override
  bool isValidKey(Object? o) => o is SearchHistoryRecord;
}
