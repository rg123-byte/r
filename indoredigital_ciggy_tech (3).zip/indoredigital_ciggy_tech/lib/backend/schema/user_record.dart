import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserRecord extends FirestoreRecord {
  UserRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  bool hasBio() => _bio != null;

  // "AGE" field.
  String? _age;
  String get age => _age ?? '';
  bool hasAge() => _age != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  bool hasCountry() => _country != null;

  // "role" field.
  String? _role;
  String get role => _role ?? '';
  bool hasRole() => _role != null;

  // "name1" field.
  String? _name1;
  String get name1 => _name1 ?? '';
  bool hasName1() => _name1 != null;

  // "number2" field.
  String? _number2;
  String get number2 => _number2 ?? '';
  bool hasNumber2() => _number2 != null;

  // "address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  // "bussiness" field.
  String? _bussiness;
  String get bussiness => _bussiness ?? '';
  bool hasBussiness() => _bussiness != null;

  // "email2" field.
  String? _email2;
  String get email2 => _email2 ?? '';
  bool hasEmail2() => _email2 != null;

  // "name3" field.
  String? _name3;
  String get name3 => _name3 ?? '';
  bool hasName3() => _name3 != null;

  // "imageurl" field.
  String? _imageurl;
  String get imageurl => _imageurl ?? '';
  bool hasImageurl() => _imageurl != null;

  // "number" field.
  int? _number;
  int get number => _number ?? 0;
  bool hasNumber() => _number != null;

  // "vendorId" field.
  String? _vendorId;
  String get vendorId => _vendorId ?? '';
  bool hasVendorId() => _vendorId != null;

  // "vendorName" field.
  String? _vendorName;
  String get vendorName => _vendorName ?? '';
  bool hasVendorName() => _vendorName != null;

  // "vendoremail" field.
  String? _vendoremail;
  String get vendoremail => _vendoremail ?? '';
  bool hasVendoremail() => _vendoremail != null;

  // "vendorrole" field.
  String? _vendorrole;
  String get vendorrole => _vendorrole ?? '';
  bool hasVendorrole() => _vendorrole != null;

  // "vendorBussiness" field.
  String? _vendorBussiness;
  String get vendorBussiness => _vendorBussiness ?? '';
  bool hasVendorBussiness() => _vendorBussiness != null;

  // "vendornam1" field.
  String? _vendornam1;
  String get vendornam1 => _vendornam1 ?? '';
  bool hasVendornam1() => _vendornam1 != null;

  // "vendoremail1" field.
  String? _vendoremail1;
  String get vendoremail1 => _vendoremail1 ?? '';
  bool hasVendoremail1() => _vendoremail1 != null;

  // "vendorurl" field.
  String? _vendorurl;
  String get vendorurl => _vendorurl ?? '';
  bool hasVendorurl() => _vendorurl != null;

  // "vendornumber1" field.
  String? _vendornumber1;
  String get vendornumber1 => _vendornumber1 ?? '';
  bool hasVendornumber1() => _vendornumber1 != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _name = snapshotData['name'] as String?;
    _bio = snapshotData['bio'] as String?;
    _age = snapshotData['AGE'] as String?;
    _country = snapshotData['country'] as String?;
    _role = snapshotData['role'] as String?;
    _name1 = snapshotData['name1'] as String?;
    _number2 = snapshotData['number2'] as String?;
    _address = snapshotData['address'] as String?;
    _bussiness = snapshotData['bussiness'] as String?;
    _email2 = snapshotData['email2'] as String?;
    _name3 = snapshotData['name3'] as String?;
    _imageurl = snapshotData['imageurl'] as String?;
    _number = castToType<int>(snapshotData['number']);
    _vendorId = snapshotData['vendorId'] as String?;
    _vendorName = snapshotData['vendorName'] as String?;
    _vendoremail = snapshotData['vendoremail'] as String?;
    _vendorrole = snapshotData['vendorrole'] as String?;
    _vendorBussiness = snapshotData['vendorBussiness'] as String?;
    _vendornam1 = snapshotData['vendornam1'] as String?;
    _vendoremail1 = snapshotData['vendoremail1'] as String?;
    _vendorurl = snapshotData['vendorurl'] as String?;
    _vendornumber1 = snapshotData['vendornumber1'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('user');

  static Stream<UserRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UserRecord.fromSnapshot(s));

  static Future<UserRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UserRecord.fromSnapshot(s));

  static UserRecord fromSnapshot(DocumentSnapshot snapshot) => UserRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UserRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UserRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UserRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UserRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUserRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? name,
  String? bio,
  String? age,
  String? country,
  String? role,
  String? name1,
  String? number2,
  String? address,
  String? bussiness,
  String? email2,
  String? name3,
  String? imageurl,
  int? number,
  String? vendorId,
  String? vendorName,
  String? vendoremail,
  String? vendorrole,
  String? vendorBussiness,
  String? vendornam1,
  String? vendoremail1,
  String? vendorurl,
  String? vendornumber1,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'name': name,
      'bio': bio,
      'AGE': age,
      'country': country,
      'role': role,
      'name1': name1,
      'number2': number2,
      'address': address,
      'bussiness': bussiness,
      'email2': email2,
      'name3': name3,
      'imageurl': imageurl,
      'number': number,
      'vendorId': vendorId,
      'vendorName': vendorName,
      'vendoremail': vendoremail,
      'vendorrole': vendorrole,
      'vendorBussiness': vendorBussiness,
      'vendornam1': vendornam1,
      'vendoremail1': vendoremail1,
      'vendorurl': vendorurl,
      'vendornumber1': vendornumber1,
    }.withoutNulls,
  );

  return firestoreData;
}

class UserRecordDocumentEquality implements Equality<UserRecord> {
  const UserRecordDocumentEquality();

  @override
  bool equals(UserRecord? e1, UserRecord? e2) {
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.name == e2?.name &&
        e1?.bio == e2?.bio &&
        e1?.age == e2?.age &&
        e1?.country == e2?.country &&
        e1?.role == e2?.role &&
        e1?.name1 == e2?.name1 &&
        e1?.number2 == e2?.number2 &&
        e1?.address == e2?.address &&
        e1?.bussiness == e2?.bussiness &&
        e1?.email2 == e2?.email2 &&
        e1?.name3 == e2?.name3 &&
        e1?.imageurl == e2?.imageurl &&
        e1?.number == e2?.number &&
        e1?.vendorId == e2?.vendorId &&
        e1?.vendorName == e2?.vendorName &&
        e1?.vendoremail == e2?.vendoremail &&
        e1?.vendorrole == e2?.vendorrole &&
        e1?.vendorBussiness == e2?.vendorBussiness &&
        e1?.vendornam1 == e2?.vendornam1 &&
        e1?.vendoremail1 == e2?.vendoremail1 &&
        e1?.vendorurl == e2?.vendorurl &&
        e1?.vendornumber1 == e2?.vendornumber1;
  }

  @override
  int hash(UserRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.name,
        e?.bio,
        e?.age,
        e?.country,
        e?.role,
        e?.name1,
        e?.number2,
        e?.address,
        e?.bussiness,
        e?.email2,
        e?.name3,
        e?.imageurl,
        e?.number,
        e?.vendorId,
        e?.vendorName,
        e?.vendoremail,
        e?.vendorrole,
        e?.vendorBussiness,
        e?.vendornam1,
        e?.vendoremail1,
        e?.vendorurl,
        e?.vendornumber1
      ]);

  @override
  bool isValidKey(Object? o) => o is UserRecord;
}
