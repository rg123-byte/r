import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VendorprofileRecord extends FirestoreRecord {
  VendorprofileRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "phonenumber" field.
  String? _phonenumber;
  String get phonenumber => _phonenumber ?? '';
  bool hasPhonenumber() => _phonenumber != null;

  // "busines" field.
  String? _busines;
  String get busines => _busines ?? '';
  bool hasBusines() => _busines != null;

  // "Adress" field.
  String? _adress;
  String get adress => _adress ?? '';
  bool hasAdress() => _adress != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "imageurl" field.
  String? _imageurl;
  String get imageurl => _imageurl ?? '';
  bool hasImageurl() => _imageurl != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _phonenumber = snapshotData['phonenumber'] as String?;
    _busines = snapshotData['busines'] as String?;
    _adress = snapshotData['Adress'] as String?;
    _email = snapshotData['email'] as String?;
    _imageurl = snapshotData['imageurl'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('vendorprofile');

  static Stream<VendorprofileRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VendorprofileRecord.fromSnapshot(s));

  static Future<VendorprofileRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => VendorprofileRecord.fromSnapshot(s));

  static VendorprofileRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VendorprofileRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VendorprofileRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VendorprofileRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VendorprofileRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VendorprofileRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVendorprofileRecordData({
  String? name,
  String? phonenumber,
  String? busines,
  String? adress,
  String? email,
  String? imageurl,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'phonenumber': phonenumber,
      'busines': busines,
      'Adress': adress,
      'email': email,
      'imageurl': imageurl,
    }.withoutNulls,
  );

  return firestoreData;
}

class VendorprofileRecordDocumentEquality
    implements Equality<VendorprofileRecord> {
  const VendorprofileRecordDocumentEquality();

  @override
  bool equals(VendorprofileRecord? e1, VendorprofileRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.phonenumber == e2?.phonenumber &&
        e1?.busines == e2?.busines &&
        e1?.adress == e2?.adress &&
        e1?.email == e2?.email &&
        e1?.imageurl == e2?.imageurl;
  }

  @override
  int hash(VendorprofileRecord? e) => const ListEquality().hash(
      [e?.name, e?.phonenumber, e?.busines, e?.adress, e?.email, e?.imageurl]);

  @override
  bool isValidKey(Object? o) => o is VendorprofileRecord;
}
