import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BeautyRecord extends FirestoreRecord {
  BeautyRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "Number" field.
  String? _number;
  String get number => _number ?? '';
  bool hasNumber() => _number != null;

  // "Hours" field.
  String? _hours;
  String get hours => _hours ?? '';
  bool hasHours() => _hours != null;

  // "imageUrl" field.
  String? _imageUrl;
  String get imageUrl => _imageUrl ?? '';
  bool hasImageUrl() => _imageUrl != null;

  // "NAME" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  void _initializeFields() {
    _location = snapshotData['location'] as String?;
    _number = snapshotData['Number'] as String?;
    _hours = snapshotData['Hours'] as String?;
    _imageUrl = snapshotData['imageUrl'] as String?;
    _name = snapshotData['NAME'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('beauty');

  static Stream<BeautyRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BeautyRecord.fromSnapshot(s));

  static Future<BeautyRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BeautyRecord.fromSnapshot(s));

  static BeautyRecord fromSnapshot(DocumentSnapshot snapshot) => BeautyRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BeautyRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BeautyRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BeautyRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BeautyRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBeautyRecordData({
  String? location,
  String? number,
  String? hours,
  String? imageUrl,
  String? name,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'location': location,
      'Number': number,
      'Hours': hours,
      'imageUrl': imageUrl,
      'NAME': name,
    }.withoutNulls,
  );

  return firestoreData;
}

class BeautyRecordDocumentEquality implements Equality<BeautyRecord> {
  const BeautyRecordDocumentEquality();

  @override
  bool equals(BeautyRecord? e1, BeautyRecord? e2) {
    return e1?.location == e2?.location &&
        e1?.number == e2?.number &&
        e1?.hours == e2?.hours &&
        e1?.imageUrl == e2?.imageUrl &&
        e1?.name == e2?.name;
  }

  @override
  int hash(BeautyRecord? e) => const ListEquality()
      .hash([e?.location, e?.number, e?.hours, e?.imageUrl, e?.name]);

  @override
  bool isValidKey(Object? o) => o is BeautyRecord;
}
