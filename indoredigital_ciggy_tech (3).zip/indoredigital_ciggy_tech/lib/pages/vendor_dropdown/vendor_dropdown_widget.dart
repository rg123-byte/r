import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'vendor_dropdown_model.dart';
export 'vendor_dropdown_model.dart';

class VendorDropdownWidget extends StatefulWidget {
  const VendorDropdownWidget({super.key});

  @override
  State<VendorDropdownWidget> createState() => _VendorDropdownWidgetState();
}

class _VendorDropdownWidgetState extends State<VendorDropdownWidget> {
  late VendorDropdownModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => VendorDropdownModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: AlignmentDirectional(0.0, 0.0),
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
        child: StreamBuilder<List<VendorRecord>>(
          stream: queryVendorRecord()
            ..listen((snapshot) {
              List<VendorRecord> dropDownVendorRecordList = snapshot;
              if (_model.dropDownPreviousSnapshot != null &&
                  !const ListEquality(VendorRecordDocumentEquality()).equals(
                      dropDownVendorRecordList,
                      _model.dropDownPreviousSnapshot)) {
                () async {
                  await currentUserReference!.update(createUserRecordData());

                  safeSetState(() {});
                }();
              }
              _model.dropDownPreviousSnapshot = snapshot;
            }),
          builder: (context, snapshot) {
            // Customize what your widget looks like when it's loading.
            if (!snapshot.hasData) {
              return Center(
                child: SizedBox(
                  width: 50.0,
                  height: 50.0,
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      FlutterFlowTheme.of(context).primary,
                    ),
                  ),
                ),
              );
            }
            List<VendorRecord> dropDownVendorRecordList = snapshot.data!;

            return FlutterFlowDropDown<String>(
              controller: _model.dropDownValueController ??=
                  FormFieldController<String>(null),
              options: dropDownVendorRecordList.map((e) => e.business).toList(),
              onChanged: (val) =>
                  safeSetState(() => _model.dropDownValue = val),
              width: 200.0,
              height: 40.0,
              textStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                    fontFamily: 'Inter',
                    letterSpacing: 0.0,
                  ),
              hintText: 'Select...',
              icon: Icon(
                Icons.keyboard_arrow_down_rounded,
                color: FlutterFlowTheme.of(context).secondaryText,
                size: 24.0,
              ),
              fillColor: FlutterFlowTheme.of(context).secondaryBackground,
              elevation: 2.0,
              borderColor: Colors.transparent,
              borderWidth: 0.0,
              borderRadius: 8.0,
              margin: EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
              hidesUnderline: true,
              isOverButton: false,
              isSearchable: false,
              isMultiSelect: false,
            );
          },
        ),
      ),
    );
  }
}
