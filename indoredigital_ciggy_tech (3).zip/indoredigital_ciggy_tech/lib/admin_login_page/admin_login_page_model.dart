import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'admin_login_page_widget.dart' show AdminLoginPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AdminLoginPageModel extends FlutterFlowModel<AdminLoginPageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for emai widget.
  FocusNode? emaiFocusNode;
  TextEditingController? emaiTextController;
  String? Function(BuildContext, String?)? emaiTextControllerValidator;
  // State field(s) for pass widget.
  FocusNode? passFocusNode;
  TextEditingController? passTextController;
  late bool passVisibility;
  String? Function(BuildContext, String?)? passTextControllerValidator;

  @override
  void initState(BuildContext context) {
    passVisibility = false;
  }

  @override
  void dispose() {
    emaiFocusNode?.dispose();
    emaiTextController?.dispose();

    passFocusNode?.dispose();
    passTextController?.dispose();
  }
}
