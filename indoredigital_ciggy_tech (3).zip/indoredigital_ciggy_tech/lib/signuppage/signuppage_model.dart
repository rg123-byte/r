import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'signuppage_widget.dart' show SignuppageWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SignuppageModel extends FlutterFlowModel<SignuppageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for name widget.
  FocusNode? nameFocusNode;
  TextEditingController? nameTextController;
  String? Function(BuildContext, String?)? nameTextControllerValidator;
  // State field(s) for email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  // State field(s) for pass widget.
  FocusNode? passFocusNode;
  TextEditingController? passTextController;
  late bool passVisibility;
  String? Function(BuildContext, String?)? passTextControllerValidator;
  // State field(s) for cpass widget.
  FocusNode? cpassFocusNode;
  TextEditingController? cpassTextController;
  late bool cpassVisibility;
  String? Function(BuildContext, String?)? cpassTextControllerValidator;
  // State field(s) for num widget.
  FocusNode? numFocusNode;
  TextEditingController? numTextController;
  late bool numVisibility;
  String? Function(BuildContext, String?)? numTextControllerValidator;

  @override
  void initState(BuildContext context) {
    passVisibility = false;
    cpassVisibility = false;
    numVisibility = false;
  }

  @override
  void dispose() {
    nameFocusNode?.dispose();
    nameTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    passFocusNode?.dispose();
    passTextController?.dispose();

    cpassFocusNode?.dispose();
    cpassTextController?.dispose();

    numFocusNode?.dispose();
    numTextController?.dispose();
  }
}
