import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'hospital_copy_copy2_widget.dart' show HospitalCopyCopy2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class HospitalCopyCopy2Model extends FlutterFlowModel<HospitalCopyCopy2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
