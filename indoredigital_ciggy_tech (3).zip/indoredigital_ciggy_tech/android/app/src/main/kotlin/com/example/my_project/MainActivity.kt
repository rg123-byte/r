package com.mycompany.indoredigitalciggytech

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
